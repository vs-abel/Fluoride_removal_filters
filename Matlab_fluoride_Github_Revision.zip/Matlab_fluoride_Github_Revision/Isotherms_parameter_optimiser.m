function [ K1, chi, qm_MRC, qm_TMRC] = Isotherms_parameter_optimiser
    close all; clear all; clc; format long   
    %Code written by L. C. Auton, based on codes by M. Martínez I. Àvila and A. Valverde
    
    % Starting point for the search and bounds for each of the 4 parameters 
    %         K1    chi    qm_MRC   qmT  
    x0 = [ 4.75    0.72   0.0017    0.0069  ]; 
    lb = [ 4.5     0.64   0.001     0.0068  ];        
    ub = [ 6.0     .73    0.0018    0.007   ]; 
    
    % Define number of trial points.
    NTP = 10000;  
    % Note that the GlobalSearch algorithm, based on the work by Z. Ugray, et 
    % al. "Scatter search and local  NLP solvers: A multistart framework for 
    % global optimization." INFORMS  Journal on computing 19.3 (2007): 328-340,
    % utilises a stratified-sampling procedure to randomly generate trial points.
    % As a result, each time the same code is run, slightly different optima 
    % are produced. We have run the optimisation algorithm multiple times and 
    % selected the paramter values which yield the lowest SSE and highest R^2. 
    
    % Create the optimisation problem: 
    problem = createOptimProblem('fmincon','lb',lb,'ub',ub,'nonlcon',@mycon,'objective',@FitParam,'x0',x0);
    gs = GlobalSearch('FunctionTolerance',1e-10,'Display','iter','NumTrialPoints',NTP);
    
    % Run the optimisation
    [x, fval, exitflag] = run(gs,problem);
    K1 = x(1);
    chi = x(2); 
    qm_MRC = x(3);
    qm_TMRC = x(4);
    
    %Call function to extract paramter values TIDY THE BELOW???
    [valT, ce_model_MRC, qe_model_MRC, ce_model_TMRC,  qe_model_TMRC,...
                MRC_iso_data, TMRC_iso_data,val_MRC, val_TMRC, K2] = FitParam(x); 
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    function [valT, ce_model_MRC, qe_model_MRC, ce_model_TMRC,  qe_model_TMRC,...
            MRC_iso_data, TMRC_iso_data,val_MRC, val_TMRC, K2, K1] = FitParam(x)

        %Unpack parameters to be optimised 
        K1 = x(1);
        chi = x(2);
        qm_MRC = x(3);
        qmT = x(4);
        
        %Define experimentally prescribed paramter values 
        gamma_iso = 7; 
        gamma_kin =  1; 
        
        %Calculate qm1 and qm2 from qm_MRC and chi
        qm1 = qm_MRC*(1-chi);
        qm2 = qm_MRC*chi;
        
        %Define factors to convert until between mol/l and mg/l. 
        F_fac = 1/19000;
        OH_fac = 1/17000;
        
        %Define kinetic data for MRC and TMRC, to be used to calculate K2 and KT
        c_MRC = F_fac*[10 10 10 9.6 9.2 9 8.4 8.1 8 7.4 6.6 5.4 4.2 3.9 3.5]; %in mol/l
        c_TMRC = F_fac*[50 6.9 5.8 4.9 3.6 2 0.5 0.45 0.4 0.4 0.3 0.08 0.08 0.08]; %in mol/l
        
        %-----------------------------------------------------
        
        cOH0 = 1.7000e-3*OH_fac; %This results from pH of 7 (cOH0 = 10^{-7}mol/l) 
        
        %Calculate KT and K2 according to equations (19) and (10), respectively
        
        KT = (c_TMRC(1)-c_TMRC(end))*(c_TMRC(1)-c_TMRC(end)+cOH0)/c_TMRC(end)...
        /(gamma_kin*qmT-c_TMRC(1)+c_TMRC(end));
        
        cFe = c_MRC(end); 
        q1e_MRC = (-(cOH0+K1*cFe)+sqrt((cOH0+K1*cFe)^2+...
        4*gamma_kin*K1*cFe*qm1))/2/gamma_kin
        
        cFi = c_MRC(1);
        K2 = (cFi-cFe-gamma_kin*q1e_MRC)/cFe/...
        (gamma_kin*(qm2+q1e_MRC)+cFe-cFi)
        
        
        %Isotherm data 
        
        %TMRC
        Bce_TMRC = F_fac*[0 0 0 0.053763440860215055 0.6989247311827957 2.2580645161290325 ...
        4.89247311827957 25.053763440860216];
        Bqe_TMRC = F_fac*[0 3.1400966183574877 7.971014492753623 15.700483091787438 ...
        31.884057971014492 62.56038647342995 92.27053140096618 120.53140096618357];
        
        TMRC_iso_data = [Bce_TMRC; Bqe_TMRC ];
        %MRC 
        Bce_MRC = F_fac*[0 0 1.0905125408942202 2.1810250817884405 23.991275899672846 64.34023991275899...
        170.52631578947367 382.10526315789474 540 730.6434023991276];
        Bqe_MRC = F_fac*[0 0.684931506849315 1.5981735159817352 2.557077625570776 4.4520547945205475...
        6.415525114155251  9.132352941176471 11.316176470588236 12.75 13.378995433789953];
        
        MRC_iso_data = [Bce_MRC; Bqe_MRC ];
        
        %Analytical solution for isotherms 
        %MRC
        a = cOH0/gamma_iso;
        b = K1/gamma_iso;
        d = K1*qm1/gamma_iso; 
        qMatch_MRC = 1/2.*( -(a+b.*Bce_MRC) + ((a+b.*Bce_MRC).^2+4.*d.*Bce_MRC).^(1/2))+(qm2.*K2.*Bce_MRC)./(1+K2.*Bce_MRC);
        ce_model_MRC = linspace(Bce_MRC(1), Bce_MRC(end), 1000); 
        qe_model_MRC = 1/2.*( -(a+b.*ce_model_MRC) + ((a+b.*ce_model_MRC).^2+4.*d.*ce_model_MRC).^(1/2))+(qm2.*K2.*ce_model_MRC)./(1+K2.*ce_model_MRC);
        
        %TMRC
        bT = KT/gamma_iso; dT = KT*qmT/gamma_iso;
        qMatch_TMRC = 1/2.*(-(a+bT.*Bce_TMRC) + ((a+bT.*Bce_TMRC).^2+4.*dT.*Bce_TMRC).^(1/2));
        ce_model_TMRC = linspace(Bce_TMRC(1), Bce_TMRC(end), 1000); 
        qe_model_TMRC =1/2.*(-(a+bT.*ce_model_TMRC) + ((a+bT.*ce_model_TMRC).^2+4.*dT.*ce_model_TMRC).^(1/2));
        
        %------------------------------------------------------------
        % Isotherm
        
        %Calculate the residual function, based on the absolute value between
        %the model and data at the data points. 
        
        %Check for physicality of MRC solution
        aaa = find(qe_model_TMRC<0); 
        if sum(aaa) > 0
            val_MRC = 10; 
        else 
            val_MRC = sum( abs(Bqe_MRC-qMatch_MRC))./Bqe_MRC(end);
        end
        val_TMRC = sum(abs(Bqe_TMRC-qMatch_TMRC))/Bqe_TMRC(end);
        
        %Define a global objective function 
        valT = val_MRC+val_TMRC; 

    end

    function [constraint_ineq,constraint_eq] = mycon(x)
        %This function provides an inequality constraint --- that is, we enforce that
        %K2>0, as physically required
    
        %Unpack MRC isotherm parameters 
        K1 = x(1);
        chi = x(2);
        qm_MRC = x(3);
    
        %construct qm1 and qm2 from qm_MRC and chi.
        qm1 = qm_MRC*(1-chi);
        qm2 = qm_MRC*chi;
    
        %Define the kinetic dose
        gamma_kin = 1; 
        % -----------------------------------
        %Define factors to convert units between mg/l and mol/l
        F_fac = 1/19000;
        OH_fac = 1/17000;
        c_MRC = F_fac*[10 10 10 9.6 9.2 9 8.4 8.1 8 7.4 6.6 5.4 4.2 3.9 3.5];
      
        %-----------------------------------------------------
        cOH0 = 1.7000e-3*OH_fac; %Intial value of OH based on pH =7. 
    
        %Calculate K2 based on Equation (10)
        cFe = c_MRC(end); 
        q1e_MRC = (-(cOH0+K1*cFe)+sqrt((cOH0+K1*cFe)^2+...
            4*gamma_kin*K1*cFe*qm1))/2/gamma_kin;
        cFi = c_MRC(1);
        
        K2 = (cFi-cFe-gamma_kin*q1e_MRC)/cFe/...
            (gamma_kin*(qm2+q1e_MRC)+cFe-cFi);
        %-----------------------------------------------------
        constraint_ineq=-K2; %inequality constraint
        constraint_eq=[];  %No equality constraint prescribed 
    end

end 
