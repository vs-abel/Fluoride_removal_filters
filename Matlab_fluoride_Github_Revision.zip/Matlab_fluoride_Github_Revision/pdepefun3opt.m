function [c,f,s] = pdepefun3opt(x,t,u,dudx,v,D1,D2,rhob1,rhobT,phi,ka1,kaT,ka2,kd1,kdT,kd2,qm1,qmT,qm2)
    %Code written by M. Martínez I. Àvila and A. Valverde

    %Function to construct PDEs (Equations 20a--e) in correct format for
    %MATLAB function pdepe, to be used in the optimisation.
    %For details on c f s, search matlab pdepe
    % Here,  u(1) = cF,  u(2) = cOH, u(3) = q1, u(4) = qT, u(5) = q2
    c = [1;1;1;1;1]; 
    f = [-v;-v;0;0;0].*u+[D1;D2;0;0;0].*dudx; 
    s = [-(1/phi)*( rhob1*(ka1*u(1)*(qm1-u(3))-kd1*u(3)*u(2)) ...
        + rhobT*(kaT*u(1)*(qmT-u(4))-kdT*u(4)*u(2)) + rhob1*(ka2*u(1)*(qm2-u(5))-kd2*u(5)));
        (1/phi)*(   rhob1*(ka1*u(1)*(qm1-u(3))-kd1*u(3)*u(2)) ...
        + rhobT*(kaT*u(1)*(qmT-u(4))-kdT*u(4)*u(2))    );
        ka1*u(1)*(qm1-u(3))-kd1*u(3)*u(2);
        kaT*u(1)*(qmT-u(4))-kdT*u(4)*u(2);  
        ka2*u(1)*(qm2-u(5))-kd2*u(5)
        ];
end