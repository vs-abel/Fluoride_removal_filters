% Code written by L. C. Auton and A. Valverde
% This code produces pdfs of Figure 14.

close all; clear all; clc; 

%Define physcial parameters
    D1=2.9e-5;
    D2=2.9e-5;
    gamma_kin=1; 
    F_fac = 1/19000;
    OH_fac = 1/17000;
    cOH0 = 1.7000e-3*OH_fac; 
    
    %Manually input MRC batch parameters and calculate K2: 
    K1 =4.7401 ;  
    chi  = 0.72852;
    qm_MRC = 0.0017448; 
    qm1 =  qm_MRC*(1-chi);
    qm2 = chi*qm_MRC;
    
    c_MRC = F_fac*[10 10 10 9.6 9.2 9 8.4 8.1 8 7.4 6.6 5.4 4.2 3.9 3.5];
    
    cFe = c_MRC(end); 
    q1e_MRC = (-(cOH0+K1*cFe)+sqrt((cOH0+K1*cFe)^2+...
    4*gamma_kin*K1*cFe*qm1))/2/gamma_kin;
    cFi = c_MRC(1);
    
    K2 = (cFi-cFe-gamma_kin*q1e_MRC)/cFe/...
    (gamma_kin*(qm2+q1e_MRC)+cFe-cFi);
    
    %Manually input TMRC batch parameters and calculate KT: 
    qmT = 0.0069001;
    
    c_TMRC = F_fac*[50 6.9 5.8 4.9 3.6 2 0.5 0.45 0.4 0.4 0.3 0.08 0.08 0.08];
    
    KT = (c_TMRC(1)-c_TMRC(end))*(c_TMRC(1)-c_TMRC(end)+cOH0)/c_TMRC(end)...
    /(gamma_kin*qmT-c_TMRC(1)+c_TMRC(end));
    
    qm1 =  qm_MRC*(1-chi);
    qm2 = chi*qm_MRC;
    
    
    % Defines desired data and parameters for this case
    c1i_F=10*F_fac;
    fs_F = 1/41;  
    Lb_F=1;
    
    Qs = 30/24/3600; % [dm^3/s]
    
    Q = Qs;   
    c1i = c1i_F;                       
    Lb = Lb_F;
    factor  = fs_F;

    ka1 = [ 0.0002   0.0002   0.0002   0.0002   0.0002*2   0.0002*10   0.0002   0.0002   0.0002];
    kaT = [ 0.06   0.06*2   0.06*10   0.06   0.06   0.06   0.06   0.06   0.06];
    ka2 = [0.0002   0.0002   0.0002   0.0002   0.0002   0.0002   0.0002   0.0002/20   0.0002/100];
    kd1=ka1/K1;         
    kdT=kaT/KT;      
    kd2=ka2/K2; 
    
    celllength=max(size(ka1));
    
    %Defines and calculate column parameters
    Db=4.4e-1;          %dm
    Sb=pi*(Db^2)/4;     %dm^2
    vs=Q/Sb;            %Initial superficial velocity [dm/s]
    rhob1=(1-factor)*900;            
    rhob2=factor*980;
    phi=(1-factor)*0.5+factor*0.6;
    v=vs/phi; 
    
    
    xb=Lb;
    
    xend=xb;
    N=200; 
    points = 1e3; 
    tmax=250*3600;
    
    T = 1;
    tmesh = logspace(-2,log10(T*tmax),points);
    xmesh = linspace(0,xend,N); 
    [~,Nbi] = min(abs(xmesh-xb)); % Outlet position
    
    %Declare cell variables
    
    sol=cell(1,celllength);
    
    c1=cell(1,celllength);
    c2=cell(1,celllength);
    q1=cell(1,celllength);
    qT=cell(1,celllength);
    q2=cell(1,celllength);
    
    c1out=cell(1,celllength);
    c2out=cell(1,celllength);
    q1out=cell(1,celllength);
    qTout=cell(1,celllength);
    q2out=cell(1,celllength);
    
    q_MRC2_eqm = cell(1,celllength);
    q_MRC1_eqm = cell(1,celllength);
    q_TMRC_eqm = cell(1,celllength);
    
    %Solve PDE
    mpdepe = 0;
    i=1;
    while i<=celllength
        sol{i} = pdepe(mpdepe,@(x,t,u,dudx) ...
        pdepefun3opt(x,t,u,dudx,v,D1,D2,rhob1,rhob2,phi,ka1(i),...
        kaT(i),ka2(i),kd1(i),kdT(i),kd2(i),qm1,qmT,qm2),...
        @(x) pdepeic3opt(x,cOH0),@(xl,ul,xr,ur,t) ...
        pdepebc3opt(xl,ul,xr,ur,t,v,c1i,cOH0),xmesh,tmesh);
    
        %Unpack physcial quantities 
        c1{i}=sol{i}(:,:,1);
        c2{i}=sol{i}(:,:,2);
        q1{i}=sol{i}(:,:,3);
        qT{i}=sol{i}(:,:,4);
        q2{i}=sol{i}(:,:,5);
    
        %Finding solution at the outlet
        c1out{i}=c1{i}(:,Nbi);
        c2out{i}=c2{i}(:,Nbi);
        q1out{i}=q1{i}(:,Nbi);
        qTout{i}=qT{i}(:,Nbi);
        q2out{i}=q2{i}(:,Nbi);

        %Calculate equalibrium values for q
        q_MRC2_eqm{i} = K2*c1i/(1+K2*c1i);
        q_MRC1_eqm{i} = K1*c1i/(cOH0+K1*c1i);
        q_TMRC_eqm{i} = KT*c1i/(cOH0+KT*c1i);


        i=i+1;
    end
    
    %Plotting paramters
    FS1=11;  % Font size for text
    LW=1;
    LW2=1.5; % Line width
    
    nc = 100; 
    
    figure(1)
    
    %Subplot 1
    subplot(121)
    hold on 
    title('\textbf{Full model: Varying} $k_\mathrm{T}^\mathrm{a}$','Interpreter','latex');
    %Define colour maps
    cmap=copper(nc);
    cmaps = [cmap(round((nc+20)/4),:); cmap(round((nc+20)/2),:); cmap(round(3*(nc+20)/4)-10,:)];
    
    iini=1;
    i=iini;
    while i<=iini+2 
            plot(tmesh'/3600,c1out{i}'/c1i,'LineWidth',LW,'Color', cmaps(i-iini+1,:))            
            hold all     
            %xlim([0 tmax/3600]);
            xlim([0 100]);
         
            i=i+1;
    end
    grid off
    hold on
    box on 
    ylim([-0.1 1.01])
    set(gca,'FontSize',FS1,'FontName','Times New Roman','LineWidth', 1)
    xlabel('t (hours)','Interpreter','latex')
    ylabel('$c_\mathrm{F}^\mathrm{out}/c_\mathrm{F}^\mathrm{f}$','Interpreter','latex');  
        
    %Subplot 2
        
     subplot(122)
     hold on 
     title('\textbf{Full model: Varying} $k_\mathrm{1}^\mathrm{a}$ \textbf{and} $k_\mathrm{2}^\mathrm{a}$','Interpreter','latex')
       
     %Define colour maps
     cmap = parula(nc); 
     cmap = [cmap(2:end,:)];
     cmaps = [cmap(round((nc+20)/4),:); cmap(round((nc+20)/2),:); cmap(round(3*(nc+20)/4)-10,:)];

     iini=4;
     i=iini;
     while i<=iini+2 
            plot(tmesh'/3600,c1out{i}'/c1i,'LineWidth',LW,'Color', cmaps(i-iini+1,:))            
            hold all
            %xlim([0 tmax/3600]);
            xlim([0 100]);
         
            i=i+1;
     end
     
     
     %Define colour maps
     cmap = parula(nc); 
     cmap = [cmap(2:end,:)];
     cmaps = [cmap(round((nc-20)/4),:); cmap(round((nc-20)/2),:); cmap(round(3*(nc-20)/4)+10,:)];
     
     iini=7;
     i=iini;
     while i<=iini+2 
            plot(tmesh'/3600,c1out{i}'/c1i,'--k','LineWidth',LW,'Color', cmaps(i-iini+1,:))            
            hold all     
            %xlim([0 tmax/3600]);
            xlim([0 100]);
         
            i=i+1;
     end
     grid off
     hold on
     box on 
     ylim([-0.1 1.01])
     set(gca,'FontSize',FS1,'FontName','Times New Roman','LineWidth', 1)
     xlabel('t (hours)','Interpreter','latex')
    
        
     %Set plotting parameters: make plot pretty
     figw = 17.2; % cm
     subfigw = 0.425; % Fraction of figw
     subfigh = 0.75; % Fraction of figh
     padleft = 1.3/figw; % Fraction of figw
     padbottom = 2.8/figw; % Fraction of figw
     padbetween = 0.75/figw; % Fraction of figw
     figh = figw/(2.7); 

     subplot(1,2,1)
     set(gca,'Position',[padleft,padbottom,subfigw,subfigh])
     subplot(1,2,2)
     set(gca,'Position',[padleft+(subfigw+1.4*padbetween),padbottom,subfigw,subfigh])
     set(gcf,'PaperUnits','centimeters')
     set(gcf,'PaperSize',[figw+0.05 figh])
     set(gcf,'PaperPosition',[0 0 figw figh])

     print(gcf,'-dpdf','./Figures/fig_14.pdf'); 
