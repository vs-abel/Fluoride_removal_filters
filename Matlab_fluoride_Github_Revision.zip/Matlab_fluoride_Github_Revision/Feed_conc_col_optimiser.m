close all; clear all; clc; format long
%Code written by L. C. Auton, based on codes by M. Martínez I. Àvila and A. Valverde

%Load experimental data
[Data5C, Data10C, Data15C, Data_tsC, Data_csC] =Data_Concentrations;

% Batch optimised values 
% MRC
K1 =4.7401 ;  
chi  = 0.72852;
qm_MRC = 0.0017448; 

%TMRC
qmT = 0.0069001;

%Calculate qm1 and qm2 from above 
qm1 =  qm_MRC*(1-chi);
qm2 = chi*qm_MRC;

%Define parameters used to calculate K2 and KT
gamma_kin=1; 
F_fac = 1/19000; % factor for fluoride to convert between mol and mg 
OH_fac = 1/17000; % factor for hydroxide to convert between mol and mg 
cOH0 = 1.7000e-3*OH_fac; %Initial concentration of OH in mol/l 

c_MRC = F_fac*[10 10 10 9.6 9.2 9 8.4 8.1 8 7.4 6.6 5.4 4.2 3.9 3.5]; %MRC kinetic data
c_TMRC = F_fac*[50 6.9 5.8 4.9 3.6 2 0.5 0.45 0.4 0.4 0.3 0.08 0.08 0.08];%TMRC kinetic data

cFe = c_MRC(end); 
q1e_MRC = (-(cOH0+K1*cFe)+sqrt((cOH0+K1*cFe)^2+...
4*gamma_kin*K1*cFe*qm1))/2/gamma_kin;
cFi = c_MRC(1);

%Calculate K2 and KT 
K2 = (cFi-cFe-gamma_kin*q1e_MRC)/cFe/...
(gamma_kin*(qm2+q1e_MRC)+cFe-cFi);

KT = (c_TMRC(1)-c_TMRC(end))*(c_TMRC(1)-c_TMRC(end)+cOH0)/c_TMRC(end)...
/(gamma_kin*qmT-c_TMRC(1)+c_TMRC(end));

% Define parameters used to calculare the velocity and the flow rate 
Q = 30/(24*3600);            %Flow rate [dm^3/s]
Db=4.4e-1;          %dm      
Sb=pi*(Db^2)/4;     %dm^2
vs=Q/Sb;  
%The effective diffusivity
D1=2.9e-5;
D2=2.9e-5;

%Initial guesses and bounds for experimental parameters to be optimised
c1i_DB0 = [ 5.4  , 9.6, 14.6  ]*F_fac;
c1i_DB0_LB =[ 4.5  , 9.5, 14.5  ]*F_fac;
c1i_DB0_UB =[ 5.5  , 10.5, 15.5  ]*F_fac;
fs0 = [1.04, 1.04,  1.02 ]/41; 
fs_LB = [.95, .95,  .95 ]/41; 
fs_UB = [1.05, 1.05,  1.05 ]/41; 
Lb0 =[1.04 1.04 1.03];   %dm 
Lb0_LB = [0.95 0.95 0.95]; %dm 
Lb0_UB = [1.05 1.05 1.05]; %dm 
                        
%Define number of points in spatial discretisations
z_points=500;

%Define experimental data 
texp=[Data_tsC{1},Data_tsC{2},Data_tsC{3}];
cexp=[Data_csC{1},Data_csC{2},Data_csC{3}];
sizes=[max(size(Data_tsC{1})),max(size(Data_tsC{2})),max(size(Data_tsC{3}))];

%Construct full ICs and lower and upper bounds
paropt0=[2e-4,0.059,2e-3,c1i_DB0(1),c1i_DB0(2),c1i_DB0(3), ...
    Lb0(1),Lb0(2),Lb0(3),fs0(1), fs0(2), fs0(3)];
LB=[1e-5,0.045,1e-6,c1i_DB0_LB(1),c1i_DB0_LB(2),c1i_DB0_LB(3),...
    Lb0_LB(1),Lb0_LB(2),Lb0_LB(3),fs_LB(1), fs_LB(2), fs_LB(3)];
UB=[5e-4,0.07,0.1,c1i_DB0_UB(1),c1i_DB0_UB(2),c1i_DB0_UB(3),...
    Lb0_UB(1),Lb0_UB(2),Lb0_UB(3),fs_UB(1), fs_UB(2), fs_UB(3)];

%Define options for the optimisation 
opts =optimoptions(@lsqcurvefit,'Display','iter','FunctionTolerance',1e-14,...
    'MaxIterations',500, 'StepTolerance',1e-8);

% %Optimise
% [paropt,resnorm,residual,exitflag,output,lambda,jacobian] = ...
%     lsqcurvefit(@(paropt,xexp)Feed_conc_opt_helper...
%     (paropt,xexp,D1,D2,vs,qm1,qmT,qm2,cOH0,K1,KT,K2,sizes,cexp,z_points),...
%     paropt0,texp,cexp,LB,UB,opts);

%conf=nlparci(paropt, residual, 'jacobian', jacobian);
 
%Saved optimal values 
paropt =[0.000218525298498   0.059410184426484   0.000203141587437...
0.000286101724176   0.000500000000022   0.000763157898324...
1.049997361264694   1.049992791921470   1.005856315471608...
0.025609755500764   0.025609634581970   0.025462552404319];

% Unpack the optimised parameters
ka1opt=paropt(1); 
kaTopt=paropt(2); 
ka2opt=paropt(3); 
cfopt = paropt(4:6); 
cfopt_units = paropt(4:6)/F_fac; 
Lbopt = paropt(7:9);
fopt_percentage = paropt(10:12)*41;

kd1opt= ka1opt/K1;
kd2opt= ka2opt/K2;
kdTopt= kaTopt/KT;

number = 3; 

%Preallocate vectors for speed
xmesh = zeros(z_points,number);
c1{1} = zeros(length(Data_tsC{1}), z_points);
c1{2} = zeros(length(Data_tsC{2}), z_points);
c1{3} = zeros(length(Data_tsC{3}), z_points);
c1out{1} = zeros(length(Data_tsC{1}),1) ; 
c1out{2} = zeros(length(Data_tsC{2}),1) ; 
c1out{3} = zeros(length(Data_tsC{3}),1) ; 
tmesh_exp{1} = zeros(length(Data_tsC{1}),1); 
tmesh_exp{2} = zeros(length(Data_tsC{2}),1); 
tmesh_exp{3} = zeros(length(Data_tsC{3}),1); 
val_SSE= zeros(1,3);
val_SST= val_SSE;
R_2= val_SSE;

for iExp = 1:number
    % Construct spatial mesh for each experiment 
    xmesh(:,iExp) = linspace(0, paropt(iExp+6), z_points);

    % Unpack the remaining optimised parameters
    c1i=paropt(iExp+3);
    f = paropt(iExp+9);
    
    %Calculate physcial quantities to be used to solve the pde. 
    rhob1=(1-f)*900;    
    rhob2=f*980;
    phi=(1-f)*0.5+f*0.6;
    v=vs/phi; %Interstitial velocity [dm/s]
    
    %Unpack experimental data
    cexpiExp = Data_csC{iExp}; 
    texpiExp = Data_tsC{iExp};
    
    %Construct temporal mesh which corresponds to experimental times  
    texps=texpiExp*3600;
    tmesh_exp{iExp}(:) = texps;
    
    %Solve PDE
    mpdepe = 0;
    sol = pdepe(mpdepe,@(x,t,u,dudx) ...
    pdepefun3opt(x,t,u,dudx,v,D1,D2,rhob1,rhob2,phi,ka1opt,...
    kaTopt,ka2opt,kd1opt,kdTopt,kd2opt,qm1,qmT,qm2),...
    @(x) pdepeic3opt(x,cOH0),@(xl,ul,xr,ur,t) ...
    pdepebc3opt(xl,ul,xr,ur,t,v,c1i,cOH0),xmesh(:,iExp),tmesh_exp{iExp}(:));
    
    %Extract the concentration of fluoride (cF)
    c1{iExp}=sol(:,:,1);
    %Finding cF at the outlet
    c1out{iExp}=c1{iExp}(:,end);

    %Calculate GoF parameters
    val_SSE(iExp) = sum( (cexpiExp'-c1out{iExp}/c1i).^2) ;
    val_SST(iExp) = sum( (cexpiExp'-mean(cexpiExp)).^2);
    R_2(iExp) = 1-val_SSE(iExp)./val_SST(iExp);

end

%Table 3 (left half)
disp(['Table 3 (left): Optimised and goodness of fit parameters for column ...' ...
    'filter for case of varying feed concentration and the full model'])
disp(['kaT = ' num2str(kaTopt) ' l/(mol*s)'])
disp(['ka1 = ' num2str(ka1opt) ' l/(mol*s)'])
disp(['ka2 = ' num2str(ka2opt) ' l/(mol*s)'])
disp(['cFf= ' num2str(cfopt_units) '  mg/l  (' num2str(cfopt)  ')    (mol/l)'])
disp(['f= [' num2str(fopt_percentage) ']/41    --'])
disp(['L= ' num2str(Lbopt/10) '   m'])
disp(['SSE = ' num2str(val_SSE) '    --'])
disp(['R-squared = ' num2str(R_2) '    --'])




