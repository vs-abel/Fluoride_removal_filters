close all; clear all; clc

%Code written by L. C. Auton, based on codes by M. Martínez I. Àvila and A. Valverde

%Load experimental data
[Data30F, Data40F, Data50F, Data_tsF, Data_csF] =Data_Flow_rates; 

% Batch optimised values 
% MRC
K1 =4.7401 ;  
chi  = 0.72852;
qm_MRC = 0.0017448; 

%TMRC
qmT = 0.0069001;

%Calculate qm1 and qm2 from above 
qm1 =  qm_MRC*(1-chi);
qm2 = chi*qm_MRC;

%Define parameters used to calculate K2 and KT
gamma_kin=1; 
F_fac = 1/19000; % factor for fluoride to convert between mol and mg 
OH_fac = 1/17000; % factor for hydroxide to convert between mol and mg 
cOH0=1.7000e-3*OH_fac; %Initial concentration of OH in mol/l                          

c_MRC = F_fac*[10 10 10 9.6 9.2 9 8.4 8.1 8 7.4 6.6 5.4 4.2 3.9 3.5]; %MRC kinetic data
c_TMRC = F_fac*[50 6.9 5.8 4.9 3.6 2 0.5 0.45 0.4 0.4 0.3 0.08 0.08 0.08];%TMRC kinetic data

cFe = c_MRC(end); 
q1e_MRC = (-(cOH0+K1*cFe)+sqrt((cOH0+K1*cFe)^2+...
4*gamma_kin*K1*cFe*qm1))/2/gamma_kin;
cFi = c_MRC(1);

%Calculate K2 and KT 
K2 = (cFi-cFe-gamma_kin*q1e_MRC)/cFe/...
(gamma_kin*(qm2+q1e_MRC)+cFe-cFi);

KT = (c_TMRC(1)-c_TMRC(end))*(c_TMRC(1)-c_TMRC(end)+cOH0)/c_TMRC(end)...
/(gamma_kin*qmT-c_TMRC(1)+c_TMRC(end));

% Define parameters used to calculare the velocity and the flow rate 
Qs = [30 40 50]/(24*3600);            %Flow rate [dm^3/s]
Db=4.4e-1;          %dm      
Sb=pi*(Db^2)/4;     %dm^2
%The effective diffusivity
D1=2.9e-5;
D2=2.9e-5;

%Initial guesses for parameters to be optimised
fs0 = [1.04   1.024   0.95001]/41;
Lb0=  [1.04   1.04   0.952]; 
c_in= [9.6   9.83  10.49]*F_fac;
ka10 = [ 0.27   0.099   0.1]*1e-3;
kaT0 = [0.055   0.06912  0.087];
ka20 = [ 0.0017   0.0019   0.0018];

%Number of points used to discretise the spatial domain
z_points =200;

number = 3;

%Preallocate vectors for speed
cfopt = zeros(1,3);
fopt = cfopt; 
Lbopt = cfopt;
ka1opt = cfopt;
kaTopt = cfopt;
ka2opt = cfopt;
kd1opt = cfopt;
kdTopt = cfopt;
kd2opt = cfopt;
cfopt_units= cfopt;
fopt_percentage= cfopt;
val_SSE= cfopt;
val_SST= cfopt;
R_2= cfopt;
xmesh = zeros(z_points,3);
c1{1} = zeros(length(Data_tsF{1}), z_points);
c1{2} = zeros(length(Data_tsF{2}), z_points);
c1{3} = zeros(length(Data_tsF{3}), z_points);
c1out{1} = zeros(length(Data_tsF{1}),1); 
c1out{2} = zeros(length(Data_tsF{2}),1); 
c1out{3} = zeros(length(Data_tsF{3}),1); 
tmesh_exp{1} = zeros(length(Data_tsF{1}),1); 
tmesh_exp{2} = zeros(length(Data_tsF{2}),1); 
tmesh_exp{3} = zeros(length(Data_tsF{3}),1); 

conf=cell(1,number);

for iExp =1:number
    % Unpack flow rate and velocity    
    Q = Qs(iExp);
    vs=Q/Sb;   
    
    %Unpack experimental data
    cexp = Data_csF{iExp}; 
    texp = Data_tsF{iExp};
    
    %Construct temporal mesh which corresponds to experimental times  
    texps=texp*3600;
    tmesh_exp{iExp}(:) = texps;
    
    % Prescribe initial conditions and bounds for the optimisation
    paropt0=[c_in(iExp), fs0(iExp), Lb0(iExp), ka10(iExp), kaT0(iExp), ka20(iExp)];
    LB=[9.5*F_fac, .95/41, .95  1e-5 ,0.04, 1e-6];
    UB=[10.5*F_fac, 1.05/41, 1.05 1e-3, 0.1,0.01];
    
    %Define options for optimisation algorithm
    opts =optimoptions(@lsqcurvefit,'Display','iter','FunctionTolerance',1e-14,...
    'MaxIterations',500, 'StepTolerance',1e-8);

    % Optimise 
    [paropt,resnorm,residual,exitflag,output,lambda,jacobian] = lsqcurvefit(@(paropt,texp)...
    Varying_flow_rate_opt_helper(paropt,texp,D1,D2,vs,qm1,qmT,qm2,cOH0,K1,KT,K2,tmesh_exp{iExp}(:),z_points),...
    paropt0,texp,cexp,LB,UB,opts);
    
    conf{iExp}=nlparci(paropt, residual, 'jacobian', jacobian);

    % Unpack the optimised parameters
    cfopt(iExp)=paropt(1);
    fopt(iExp) = paropt(2);
    Lbopt(iExp) = paropt(3);
    ka1opt(iExp)=paropt(4);
    kaTopt(iExp)=paropt(5);
    ka2opt(iExp)=paropt(6);
    kd1opt(iExp)=ka1opt(iExp)/K1;
    kdTopt(iExp)=kaTopt(iExp)/KT;
    kd2opt(iExp)=ka2opt(iExp)/K2;
    cfopt_units =  cfopt/F_fac;
    fopt_percentage = fopt*41;
    
    %Calculate physcial quantities to be used to solve the pde. 
    rhob1=(1-fopt(iExp))*900;               
    rhob2=fopt(iExp)*980;
    phi=(1-fopt(iExp))*0.5+fopt(iExp)*0.6;
    v=vs/phi;    %Interstitial velocity [dm/s]
    
    %Construct spatial mesh 
    xmesh(:,iExp) = linspace(0, Lbopt(iExp), z_points);
    
    %Solve PDE
    mpdepe = 0;
    sol = pdepe(mpdepe,@(x,t,u,dudx)...
    pdepefun3opt(x,t,u,dudx,v,D1,D2,rhob1,rhob2,phi,...
    ka1opt(iExp),kaTopt(iExp),ka2opt(iExp),kd1opt(iExp),kdTopt(iExp),kd2opt(iExp)...
    ,qm1,qmT,qm2),@(x) pdepeic3opt(x,cOH0),@(xl,ul,xr,ur,t) ...
    pdepebc3opt(xl,ul,xr,ur,t,v,cfopt(iExp),cOH0),xmesh(:,iExp),tmesh_exp{iExp}(:));
    
    %Extract the concentration of fluoride (cF)
    c1{iExp}=sol(:,:,1);
    
    %Finding cF at the outlet
    c1out{iExp}=c1{iExp}(:,z_points);
    
    %Calculate GoF parameters
    val_SSE(iExp) = sum( (cexp'-c1out{iExp}/cfopt(iExp)).^2); 
    val_SST(iExp) = sum( (cexp'-mean(cexp)).^2);
    R_2(iExp) = 1-val_SSE(iExp)./val_SST(iExp);

end


%Table 3 (right half)
disp(['Table 3 (right): Optimised and goodness of fit parameters for column ...' ...
    'filter for case of varying Q and the full model'])
disp(['kaT = ' num2str(kaTopt) ' l/(mol*s)'])
disp(['ka1 = ' num2str(ka1opt) ' l/(mol*s)'])
disp(['ka2 = ' num2str(ka2opt) ' l/(mol*s)'])
disp(['cFf= ' num2str(cfopt_units) '  mg/l   (' num2str(cfopt)  ')     (mol/l)'])
disp(['f= ' num2str(fopt_percentage) '/41     --'])
disp(['L= ' num2str(Lbopt/10) '   m'])
disp(['SSE = ' num2str(val_SSE) '   --'])
disp(['R-squared = ' num2str(R_2) '   --'])

