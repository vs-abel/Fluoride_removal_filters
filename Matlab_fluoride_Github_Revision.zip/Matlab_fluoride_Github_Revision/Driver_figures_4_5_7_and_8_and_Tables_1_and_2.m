clear all; close all; clc;

% Code written by L. C. Auton
% This code produces pdfs of Figures 4, 5, 7 and 8 and generates the data for
% Tables 1 and 2. 

% To use the optimal parameter values as given in the manuscript use choice = 1. 
% To re-optimise for the fitting parameters choose: 
% choice =2 for only the 4 isotherm fitting parameters (FPs) 
% or choice = 3 for both isotherm and kinetic. For choice = 3 to work correctly,
% set method =2 in Kinetic_parameter_optimiser

% Note that the GlobalSearch algorithm, based on the work by Z. Ugray, et 
% al. "Scatter search and local  NLP solvers: A multistart framework for 
% global optimization." INFORMS  Journal on computing 19.3 (2007): 328-340,
% utilises a stratified-sampling procedure to randomly generate trial points.
% As a result, each time the same code is run, slightly different optima 
% are produced. We have run the optimisation algorithm multiple times (O(10)) and 
% selected the parameter values which yield the lowest SSE and highest R^2.

choice  = 1; 

if choice ==1 
    % choice = 1  corresponds to using the optimal parameters as corresponding 
    % to the values used in the manuscript 
    %      K1       chi       qm          qmT 
    x = [  4.7401   0.72852   0.0017448   0.0069001...
        ... % ka1                ka2                kaT
         2.776042779903596   0.388663664449639  16.499999999999876];

elseif choice ==2 
    % choice = 2 is fits for only isotherm batch parameters
    [ K1, chi, qm_MRC, qm_TMRC] = Isotherms_parameter_optimiser;
    display(['K1=' num2str(K1)])
    display(['q2/qM=' num2str(chi)])
    display(['qM_MRC=' num2str(qm_MRC)])
    display(['qM_TMRC=' num2str(qm_TMRC)])
elseif choice ==3 
    % choice = 3 fits all batch parameters, provided method =2 in
    % Kinetic_parameter_optimiser.m
    warning(['For choice 3 to work properly, must set method=2 in ...' ...
    'Kinetic_parameter_optimiser. Press any key to continue'])
    pause 
    [K1, chi, qm_MRC, qm_TMRC, ka1, ka2, kaT] = Kinetic_parameter_optimiser;
    x = [K1, chi, qm_MRC, qm_TMRC, ka1, ka2, kaT];
else 
    warning('Not a recognised option')
    pause
end 

[sse_iso_MRC,Rsquared_iso_MRC, sse_kin_MRC,Rsquared_kin_MRC,sse_iso_TMRC,Rsquared_iso_TMRC,sse_kin_TMRC,...
Rsquared_kin_TMRC, cFi_MRC, cOHi, cFe_MRC, cFi_TMRC, cFe_TMRC, K2, KT] = Batch_plotter_and_GoF_calculator(x);


%Table 1 (left column to right column)
disp('Table 1: MRC batch')
disp(['cFi = ' num2str(cFi_MRC) '   (' num2str(19000*cFi_MRC) ') mol/l (mg/l)'])
disp(['cOHi = ' num2str(cOHi) '   (' num2str(17000*cOHi) ') mol/l (mg/l)'])
disp(['cFe = ' num2str(cFe_MRC) '   (' num2str(19000*cFe_MRC) ') mol/l (mg/l)'])
disp(['K2= ' num2str(K2) ' l/mol'])
display(['K1= ' num2str(x(1))])
disp(['qM= ' num2str(x(3)) ' mol/g'])
display(['q2/qM= ' num2str(x(2))])
disp(['ka1= ' num2str(x(5)) ' l/(mol.s)'])
disp(['ka2= ' num2str(x(6)) ' l/(mol.s)'])
display(['SSE iso= ' num2str(sse_iso_MRC)])
display(['R-squared iso= ' num2str(Rsquared_iso_MRC)])
display(['SSE kin= ' num2str(sse_kin_MRC)])
display(['R-squared kin= ' num2str(Rsquared_kin_MRC)])


%Table 2 (left column to right column)
disp('Table 2: TMRC batch')
disp(['cFi = ' num2str(cFi_TMRC)  '   (' num2str(19000*cFi_TMRC) ') mol/l (mg/l)'])
disp(['cOHi = ' num2str(cOHi)  '   (' num2str(17000*cOHi) ') mol/l (mg/l)'])
disp(['cFe = ' num2str(cFe_TMRC)  '   (' num2str(19000*cFe_TMRC) ') mol/l (mg/l)'])
disp(['qM= ' num2str(x(4)) ' mol/g'])
disp(['kaT= ' num2str(x(7)) ' l/(mol.s)'])
display(['KT= ' num2str(KT)])
display(['SSE iso= ' num2str(sse_iso_TMRC)])
display(['R-squared iso= ' num2str(Rsquared_iso_TMRC)])
display(['SSE kin= ' num2str(sse_kin_TMRC)])
display(['R-squared kin= ' num2str(Rsquared_kin_TMRC)])