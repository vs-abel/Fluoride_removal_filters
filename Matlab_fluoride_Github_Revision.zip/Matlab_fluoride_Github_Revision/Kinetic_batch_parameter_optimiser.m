function [K1, chi, qm_MRC, qm_TMRC, ka1, ka2, kaT] = Kinetic_batch_parameter_optimiser
    close all
    clear all;
    clc
    format long 
    %Code written by L. C. Auton, based on codes by M. Martínez I. Àvila and A. Valverde
    
    %Set initial guess and bounds 
    %    ka1  ka2   kaT;
    x0 =[2.9, 0.55, 16.4]; 
    lb = [2,   0.1  15.5];        
    ub = [3.5, 1.5  16.5]; 
    
    %Set number of trial points (10,000)
    NTP = 10000; 
    % Note that the GlobalSearch algorithm, based on the work by Z. Ugray, et 
    % al. "Scatter search and local  NLP solvers: A multistart framework for 
    % global optimization." INFORMS  Journal on computing 19.3 (2007): 328-340,
    % utilises a stratified-sampling procedure to randomly generate trial points.
    % As a result, each time the same code is run, slightly different optima 
    % are produced. We have run the optimisation algorithm multiple times (O(10)) and 
    % selected the paramter values which yield the lowest SSE and highest R^2.
    
    %Used to generate warning re values of isotherm-fitted parameters
    [~, K1, chi, qm_MRC, qm_TMRC] = FitParam(x0);
    warning(['This code is using the following values for isotherm-optimised parameters: K1 ='...
    num2str(K1) ', chi = ' num2str(chi) ', qm_MRC = ' num2str(qm_MRC) ', qm_TMRC = ' num2str(qm_TMRC)...
    '. Please check that these are the desired values or change the variable called method in FitParam' ...
    'below. Press any key to continue.' ])
    pause 
    
    %Define problem to optimise
    problem = createOptimProblem('fmincon','lb',lb,'ub',ub,'objective',@FitParam,'x0',x0);
    gs = GlobalSearch('FunctionTolerance',1e-10,'Display','iter','NumTrialPoints',NTP);
    
    % Run optimisation
    [x, fval, exitflag] = run(gs,problem);
    
    ka1 = x(1);
    ka2 = x(2);
    kaT = x(3);
    [K1, chi, qm_MRC, qm_TMRC] = FitParam(x);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    keyboard 
    
    function [valT, K1, chi, qm_MRC, qm_TMRC] = FitParam(x)
        
        %This defines the method used to input the isotherm fitted batch
        %parameters. With method 1, the optimal values are input, as appear in the manuscript.
        % These have been determined to be optimal after numerous (O(10)) runs
        % of the optimisation code. Method 2 provides an option to fit for the isotherm 
        % parameters within this code: simply change the variable method to 2. 
        
        method  =1; 
        
        if method  == 1 
            %Manually import isotherm determined batch values as in manuscript: 
            K1 =  4.7401 ;
            chi = 0.72852 ;
            qm_MRC = 0.0017448 ;
            qm_TMRC = 0.0069001;
        elseif method ==2 
            [~, K1, chi, qm_MRC, qm_TMRC] = TIDY_Fit_isotherms_April25;
        end 
        
        %Unpack parameters to optimise
        ka1 = x(1);
        ka2 = x(2);
        kaT = x(3);
        
        %Define the kinetic dose
        gamma_kin=1; 
        
        %Construct qm1 and qm2
        qm1 = qm_MRC*(1-chi);
        qm2 = qm_MRC*chi;
        
        %-----------------
        %Define factors for converting between mg/l and mol/l for F and OH
        F_fac = 1/19000;
        OH_fac = 1/17000;
        
        %Kinetic data
        t_MRC = [0 5 10 20 40 60 120 180 240 360 480 720 1080 1440 2880];
        t_TMRC = [0 5 10 20 40 60 120 180 240 360 480 1080 1440 2880]; 
        c_MRC = F_fac*[10 10 10 9.6 9.2 9 8.4 8.1 8 7.4 6.6 5.4 4.2 3.9 3.5];
        c_TMRC = F_fac*[50 6.9 5.8 4.9 3.6 2 0.5 0.45 0.4 0.4 0.3 0.08 0.08 0.08];
        
        %-----------------------------------------------------
        cOH0 = 1.7000e-3*OH_fac; %Initial concentration of OH in mol/l based on pH=7
        %-----------------------------------------------------

        %Define useful quantities
        CF0s = [c_MRC(1) c_TMRC(1)];
        fs = [0, 1];
        tss = [0, logspace(-4,log10(3000),999)]; 
        
        % Initialise vectors (preallocate size for speed)
        cs_kin{1} = zeros(length(tss), 1);
        cs_kin{2} = cs_kin{1};
        val_kins = zeros(length(fs),1);
        
        %Calculate KT and K2 according to equations (19) and (10), respectively
        KT = (c_TMRC(1)-c_TMRC(end))*(c_TMRC(1)-c_TMRC(end)+cOH0)/c_TMRC(end)...
        /(gamma_kin*qm_TMRC-c_TMRC(1)+c_TMRC(end));
        
        cFe = c_MRC(end); 
        q1e_MRC = (-(cOH0+K1*cFe)+sqrt((cOH0+K1*cFe)^2+...
        4*gamma_kin*K1*cFe*qm1))/2/gamma_kin;
        
        K2 = (CF0s(1)-cFe-gamma_kin*q1e_MRC)/cFe/...
        (gamma_kin*(qm2+q1e_MRC)+cFe-CF0s(1));
        
        %Kinetic curves 
        for imix = 1:length(fs)
            f = fs(imix);
            cF0 = CF0s(imix);
            
            if imix == 1   
                ts_concat = t_MRC;
                cs_data = c_MRC;
                
                %Define paramters to import into the function MRC_kin_helper, 
                % which is use to solve the MRC kinetics
                params = [ka1 K1  ka2 K2 chi qm_MRC f cF0 gamma_kin];
                
                % Solve for the kinetic curves
                options = odeset('RelTol',1e-10,'AbsTol',1e-12);
                InitialCond = [0 0]; 
                [T, Y] = ode15s(@(t,x)MRC_kin_helper(t,x,params),tss,InitialCond,options);
                q1(:,1) = Y(:,1);
                q2(:,1) = Y(:,2);
                
                gammaBM = (1-f)*gamma_kin; 
                
                cs_kin{imix} = cF0-(gammaBM*(q1(:,imix)+q2(:,imix)));
            else
                ts_concat = t_TMRC;
                cs_data= c_TMRC;
                
                kdT=kaT/KT;
                A = gamma_kin*(kaT-kdT);
                B = kaT*(gamma_kin*qm_TMRC+CF0s(2))+kdT*cOH0;
                D = kaT*cF0*qm_TMRC;
                
                Rminus = (B-sqrt(B^2-4*A*D))/2/A;
                Rplus = (B+sqrt(B^2-4*A*D))/2/A;
                
                ts_TMRC_ana = tss;
                qT_ana = Rplus*(exp(-A*(Rplus-Rminus)*ts_TMRC_ana)-1)./...
                (exp(-A*(Rplus-Rminus)*ts_TMRC_ana)-Rplus/Rminus);
                
                cs_kin{imix} = cF0-gamma_kin*qT_ana;
            end 
            cMatch = interp1(T,cs_kin{imix},ts_concat); 
            val_kins(imix) = sum(abs(cs_data(1:end)-cMatch(1:end)))/cF0;
        end 
        valT = sum(val_kins); 
    end
    
    
    
    function [dQidt] = MRC_kin_helper(t,x,params)
        
        % VARIABLES
        q1 = x(1); 
        q2 = x(2); 
        
        %Unpack paramters 
        ka1 = params(1);
        K1 = params(2);
        ka2 = params(3);
        K2 = params(4);   
        chi = params(5);
        qm_MRC = params(6);
        f = params(7);
        cF0 = params(8);  
        gamma_kin= params(9);
        
        % To convert units between mg/l and mol/l for OH
        OH_fac = 1/17000;
        
        %Initial condition for OH, based on pH 7. 
        cOH0 = 1.7000e-3*OH_fac; 
        
        % Construct backward reaction rates and qm1 and qm2
        kd1 = ka1/K1;
        kd2 = ka2/K2;
        
        qm1 = qm_MRC*(1-chi);
        qm2 = qm_MRC*chi;
        
        %Present problem
        gammaBM = (1-f)*gamma_kin; 
        
        cF = cF0-(gammaBM*(q1+q2));
        cOH = cOH0+(gammaBM*(q1));
        
        %Kinetic equations
        dq1dt = ka1*cF.*(qm1-q1)-kd1*cOH.*q1;
        dq2dt = ka2*cF.*(qm2-q2)-kd2*q2;
        
        %Vector of equations to solve
        dQidt = [dq1dt; dq2dt]; 
    end 
end 
