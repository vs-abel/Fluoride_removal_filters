function [tmesh] = Column_plotter_figures_10_12_13_15_17
    %Code written by L. C. Auton, based on codes by M. Martínez I. Àvila and A. Valverde
    close all; clear all; clc;  
    
    %Controls which figures are produced:
    Plot =3; 
    Case  =1; 
    % Figure 10 is Plot = 2, Case = 0 (inset produced separately)
    % Figure 12 is Plot = 3, Case = 0
    % Figure 13 is Plot =1, Case = 0
    % Figure 15 is Plot = 2, Case = 1 (inset produced separately)
    % Figure 17 is Plot = 3, Case = 1
    
    %Define physcial parameters
    D1=2.9e-5;
    D2=2.9e-5;
    gamma_kin=1; 
    F_fac = 1/19000;
    OH_fac = 1/17000;
    cOH0 = 1.7000e-3*OH_fac; 
    
    %Manually input MRC batch parameters and calculate K2: 
    K1 =4.7401 ;  
    chi  = 0.72852;
    qm_MRC = 0.0017448; 
    qm1 =  qm_MRC*(1-chi);
    qm2 = chi*qm_MRC;
    
    c_MRC = F_fac*[10 10 10 9.6 9.2 9 8.4 8.1 8 7.4 6.6 5.4 4.2 3.9 3.5];
    
    cFe = c_MRC(end); 
    q1e_MRC = (-(cOH0+K1*cFe)+sqrt((cOH0+K1*cFe)^2+...
    4*gamma_kin*K1*cFe*qm1))/2/gamma_kin;
    cFi = c_MRC(1);
    
    K2 = (cFi-cFe-gamma_kin*q1e_MRC)/cFe/...
    (gamma_kin*(qm2+q1e_MRC)+cFe-cFi);
    
    %Manually input TMRC batch parameters and calculate KT: 
    qmT = 0.0069001;
    
    c_TMRC = F_fac*[50 6.9 5.8 4.9 3.6 2 0.5 0.45 0.4 0.4 0.3 0.08 0.08 0.08];
    
    KT = (c_TMRC(1)-c_TMRC(end))*(c_TMRC(1)-c_TMRC(end)+cOH0)/c_TMRC(end)...
    /(gamma_kin*qmT-c_TMRC(1)+c_TMRC(end));
    
    %Plotting paramters
    FS1=11;  % Font size for text
    LW=1;
    LW2=1.5; % Line width
    
    %For full model calculate qm1 and qm2, for reduced model set =0
    if Case == 1
        qm1 = 0;
        qm2 = 0;
    else 
        qm1 =  qm_MRC*(1-chi);
        qm2 = chi*qm_MRC;
    end
    
    %Set input parameters to generate the desired plot.
    if Plot == 1 
        close all;
        Study = 2; 
        Exp = 2; 
        TimeLength = 3;
        ColumnLength = 0;
        [tmesh] = column_plot(Plot, Study, Exp, Case ,ColumnLength, TimeLength, ...
            FS1, LW, LW2, K1, KT, K2, qm1, qmT, qm2,  D1,  D2 , cOH0 );
    elseif Plot == 2 
        ColumnLength = 0;
        TimeLength = 1;
        Studies = [2 1];
        if Case == 0 || Case  == 1 
            for iStud  = 1:2
                Study = Studies(iStud);
                for iE = 1:3 
                    Exp = iE; 
                    [tmesh] = column_plot(Plot, Study, Exp, Case ,ColumnLength, TimeLength, ...
                        FS1, LW, LW2, K1, KT, K2, qm1, qmT, qm2,  D1,  D2 , cOH0 );
                end 
            end 
        end 
    elseif Plot == 3 
        close all
        Study = 2;
        Exp = 2;
        TimeLength = 2;
        ColumnLength = 1;
        [tmesh] = column_plot(Plot, Study, Exp, Case ,ColumnLength, TimeLength, ...
            FS1, LW, LW2, K1, KT, K2, qm1, qmT, qm2,  D1,  D2 , cOH0 );
    end 
    
    %Produce pdf for figures 10 and 15
    if Plot == 2 
        if Case ==0 
            figure(10)
        elseif Case ==1 
            figure(15)
        end 
        
        %Set plotting parameters: make plot pretty
        figw = 17.2; % cm
        subfigw = 0.425; % Fraction of figw
        subfigh = 0.75; % Fraction of figh
        padleft = 1.3/figw; % Fraction of figw
        padbottom = 2.8/figw; % Fraction of figw
        padbetween = 0.75/figw; % Fraction of figw
        figh = figw/(2.7); 
        
        for i=1:2 
            subplot(1,2,i)
            hold on
            box on
            set(gca,'FontSize',FS1,'FontName','Times New Roman','LineWidth', 1)
            xlabel('t (hours)','Interpreter','latex')
            if i==1
                ylabel('$c_\mathrm{F}^\mathrm{out}/c_\mathrm{F}^\mathrm{f}$','Interpreter','latex');
            end   
        end
        
        subplot(1,2,1)
        set(gca,'Position',[padleft,padbottom,subfigw,subfigh])
        subplot(1,2,2)
        set(gca,'Position',[padleft+(subfigw+1.4*padbetween),padbottom,subfigw,subfigh])
        set(gcf,'PaperUnits','centimeters')
        set(gcf,'PaperSize',[figw figh])
        set(gcf,'PaperPosition',[0 0 figw figh])
        
        %Export pdfs
        if Case == 0
            print(gcf,'-dpdf','./Figures/fig_10_without_inset.pdf'); 
        elseif Case == 1 
            print(gcf,'-dpdf','./Figures/fig_15_without_inset.pdf');
        end
    end 
end


function [tmesh] = column_plot(Plot, Study, Exp, Case ,ColumnLength, TimeLength, FS1, LW, LW2, K1, KT, K2, qm1, qmT, qm2,  D1,  D2, cOH0 )
    % Define convrsion factor for mg/l to mol/l.
    F_fac=1/19000;
     
    %Manually input the optimised experimental column parameters for each of
    %the different fits conducted 
    
    %Varying feed concentration: full model
    c1i_C=[5.435932759344000   9.500000000418000  14.500000068156000]*F_fac; 
    fs_C = [1.049999975531324   1.049995017860770   1.043964648577079]/41; 
    Lb_C=[1.049997361264694   1.049992791921470   1.005856315471608];
    
    %Varying feed concentration: reduced model
    c1i_C_TMRC=[  5.145055936927441   9.500000000429139  14.500000073399070]*F_fac; 
    fs_C_TMRC = [1.049999971491194   1.049999990935747   1.049999989772167]/41;
    Lb_C_TMRC=[1.049999995342633   1.049999997604982   1.049999990464032];
    
    %Different flow rates: full model
    c1i_F=[ 9.500000000634223   9.842493978513195  10.499999999344636]*F_fac;
    fs_F = [ 1.049999948127718   1.018574889585231   0.950005927228661]/41;  
    Lb_F=[ 1.049999482492616   1.049812716254649   0.950143354992560];
    
    %Different flow rates: reduced model
    c1i_F_TMRC=[9.500000000421885   9.677938628874733  10.449039946254572]*F_fac;
    fs_F_TMRC = [1.049999999999090   1.041776987061225   0.950000000709359]/41;
    Lb_F_TMRC=[  1.049999999999978   1.048618497868054   0.983992714309677];
    
    %Define flow rates and column parameters
    Qs = [30 40 50]/24/3600; % [dm^3/s]
    
    
    if Study == 1 % Study = 1 corresponds to flow rates
        % Defines desired data and parameters for this case
        Q = Qs(Exp);   
        c1i = c1i_F(Exp);                       
        Lb = Lb_F(Exp);
        factor  = fs_F(Exp);
        [Data30, Data40, Data50] =Data_Flow_rates;
        if Exp == 1 
            Data = Data30;
        elseif Exp ==2 
            Data = Data40;
        elseif Exp ==3 
            Data = Data50;
        end 
        cexp = Data(2,:);  
        texp  = Data(1,:);
    elseif Study == 2 %Study = 2 corresponds to feed concentrations 
        % Defines desired data and parameters for this case
        c1i = c1i_C(Exp); 
        factor  = fs_C(Exp);
        Q =  Qs(1);
        Lb = Lb_C(Exp);
        [Data5, Data10, Data15] =Data_Concentrations; 
        if Exp == 1 
            Data = Data5;
        elseif Exp ==2 
            Data = Data10;
        elseif Exp ==3 
            Data = Data15;
        end 
        cexp = Data(2,:);  
        texp  = Data(1,:);
    end 
    %Converts times to seconds 
    texps=texp*3600;
    if Plot == 2 
        %So breakthrough curves continue to end of figure
        tmax=250*3600;
    else 
        tmax=max(texps);
    end 
  
    
    %Manually input optimised forward reaction rates; and calculate backward reaction rates 
    if Study == 1     % Flowrates:  
        if Case == 0 % Full model
            ka1s = [ 0.273455045879841   0.100939425788178   0.111139166357784]*1e-3;
            kaTs = [ 0.054820055676501   0.069072310356778   0.088011083127391];
            ka2s = [0.000528598249429   0.001023045183623   0.001888445703099];
            ka1 = ka1s(Exp);  
            kd1=ka1/K1;     
            kaT=kaTs(Exp);      
            kdT=kaT/KT;     
            ka2=ka2s(Exp);     
            kd2=ka2/K2;  
        elseif Case == 1 %Reduced model
            c1i = c1i_F_TMRC(Exp);                        
            Lb = Lb_F_TMRC(Exp);
            factor  = fs_F_TMRC(Exp);
            kaTs =  [  0.052961122301140   0.068286665642303   0.086629729906708];
            ka1 = 0;  
            kd1=ka1/K1;     
            kaT=kaTs(Exp);      
            kdT=kaT/KT;     
            ka2=0;     
            kd2=ka2/K2;
        end 
    
    elseif Study == 2   % Concentrations:
        if Case ==0        %Full model
            ka1=    0.000218525298498; 
            kaT=    0.059410184426484;
            ka2=    0.000203141587437; 
            
            kd1=ka1/K1; 
            kdT=kaT/KT; 
            kd2=ka2/K2;
        elseif Case == 1 %reduced model
            c1i = c1i_C_TMRC(Exp);                       
            Lb = Lb_C_TMRC(Exp);
            factor  = fs_C_TMRC(Exp); 
            ka1=0;   
            kd1=0;
            ka2=0;      
            kd2=ka2/K2;
            kaT = 0.056909999095053;
            kdT=kaT/KT; 
        end
    end 
    
    %Defines and calculate column parameters
    Db=4.4e-1;          %dm
    Sb=pi*(Db^2)/4;     %dm^2
    vs=Q/Sb;            %Initial superficial velocity [dm/s]
    rhob1=(1-factor)*900;            
    rhob2=factor*980;
    phi=(1-factor)*0.5+factor*0.6;
    v=vs/phi; 
    
    % Construct temporal and spatial meshes 
    if ColumnLength == 0 % used for plots 1 and 2
        xb=Lb;
    elseif ColumnLength == 1 %used for plot 3
        xb=Lb*6;  
    end
    xend=xb;
    N=200; 
    points = 1e3; 
    if TimeLength == 1 % plot 2 
        T = 1;
        tmesh = logspace(-2,log10(T*tmax),points);
    elseif TimeLength == 2 % Plot 3 
        T=3.5;
        %T=5;
        Long_plot_late = 20;
        Long_plot_early =11;
        div2=10000;
        timelate = linspace((div2),(T*tmax),Long_plot_late); 
        timeearly = logspace(0,log10(div2), Long_plot_early);
        tmesh = [timeearly  timelate(2:end)] ;
        N=800;
    elseif TimeLength == 3 %Plot 1 
        T = 1e5;
        tmesh1 = logspace(-2,0,points);
        tmesh2 = logspace(1e-5,log10(T*tmax),points);
        tmesh = [tmesh1 tmesh2];
    end
    xmesh = linspace(0,xend,N); 
    [~,Nbi] = min(abs(xmesh-xb)); % Outlet position
    

    %Solve PDE
    mpdepe = 0;
    sol = pdepe(mpdepe,@(x,t,u,dudx) ...
        pdepefun3opt(x,t,u,dudx,v,D1,D2,rhob1,rhob2,phi,ka1,...
        kaT,ka2,kd1,kdT,kd2,qm1,qmT,qm2),...
        @(x) pdepeic3opt(x,cOH0),@(xl,ul,xr,ur,t) ...
        pdepebc3opt(xl,ul,xr,ur,t,v,c1i,cOH0),xmesh,tmesh);
    
    %Unpack physcial quantities 
    c1=sol(:,:,1);
    c2=sol(:,:,2);
    q1=sol(:,:,3);
    qT=sol(:,:,4);
    q2=sol(:,:,5);
    
    %Finding solution at the outlet
    c1out=c1(:,Nbi);
    c2out=c2(:,Nbi);
    q1out=q1(:,Nbi);
    qTout=qT(:,Nbi);
    q2out=q2(:,Nbi);
    
    %Calculate equalibrium values for q
    q_MRC2_eqm = K2*c1i/(1+K2*c1i);
    q_MRC1_eqm = K1*c1i/(cOH0+K1*c1i);
    q_TMRC_eqm = KT*c1i/(cOH0+KT*c1i);
    
    %  Plot commands 
    if  Plot == 1 %All quantities at outlet: Figure 13
        %Define plotting parameters
        nc = 100;
        cmap2 = fliplr(parula(nc));
        
        figure(13)
        hold all
        h_main = gca;
        set(h_main,'FontSize',FS1,'FontName','Times New Roman','LineWidth',1)
        h_inset = axes('Position',[0.2 0.305 0.2 0.35]); 
        % first number increasing it moves it to the right 
        % second increasing it moves it up 
        % third number controls insert width 
        % fourth controls insert height
        set(h_inset,'FontSize',FS1-2,'FontName','Times New Roman','LineWidth',1);

        %Plot main figure  
        axes(h_main)
        hold on
        xtemax = tmax/3600;
        semilogx([xtemax,xtemax], [1e-12 1],'-.','Color',[1 0.05 0.05],'LineWidth',1)

        semilogx([tmesh(1) tmesh(end)]/3600, [q_TMRC_eqm,q_TMRC_eqm],'-','LineWidth',LW2, 'Color',[115 36 204]/255,'LineWidth',1)
        semilogx([tmesh(1) tmesh(end)]/3600, [q_MRC1_eqm,q_MRC1_eqm],':','LineWidth',LW2, 'Color',[240 150 55]/255,'LineWidth',1)
        semilogx([tmesh(1) tmesh(end)]/3600, [q_MRC2_eqm,q_MRC2_eqm],':','LineWidth',LW2, 'Color',[161 20 100]/255,'LineWidth',1)
        
        semilogx(tmesh'/3600,c1out'/c1i,'-k','LineWidth',LW2)
        semilogx(tmesh'/3600,c2out'/c1i,'-','LineWidth',LW2,'Color', [.6 0.6 .6]) 
        semilogx(tmesh'/3600,qTout'/qmT,'--','LineWidth',LW2, 'Color', cmap2(round(15*(nc)/16),:)) 
        semilogx(tmesh'/3600,q1out'/qm1,'--','LineWidth',LW2, 'Color', [0 .5  .1]); 
        semilogx(tmesh'/3600,q2out'/qm2,'--','LineWidth',LW2, 'Color',cmap2(round(8.4*(nc)/16),:))
        
        set(h_main,'FontSize',FS1,'FontName','Times New Roman','LineWidth',1)
        xlab=xlabel('$t\ $(hours)','Interpreter','latex','FontSize',FS1+1);
        xlab.FontSize=FS1;
        xlim([5e-2 10^5])
        
        leg=legend('','','','','${c}_\mathrm{F}/c_\mathrm{F}^\mathrm{f}$','${c}_\mathrm{OH}/c_\mathrm{F}^\mathrm{f}$',...
        '${q}_\mathrm{T}/q_\mathrm{T}^\mathrm{m}$','${q}_1/q_1^\mathrm{m}$','${q}_2/q_2^\mathrm{m}$');
        set(leg, 'Interpreter', 'Latex','Location','northoutside','Orientation','horizontal','FontSize',FS1-2,'LineWidth',.75)
        
        %Plot inset figure
        axes(h_inset)
        hold on;
        plot([xtemax,xtemax], [0 1],'-.','Color',[1 0.05 0.05],'LineWidth',1)

        plot([tmesh(1) tmesh(end)]/3600, [q_TMRC_eqm,q_TMRC_eqm],'-','LineWidth',LW2, 'Color',[115 36 204]/255,'LineWidth',1)
        plot([tmesh(1) tmesh(end)]/3600, [q_MRC1_eqm,q_MRC1_eqm],':','LineWidth',LW2, 'Color',[240 150 55]/255,'LineWidth',1)
        plot([tmesh(1) tmesh(end)]/3600, [q_MRC2_eqm,q_MRC2_eqm],':','LineWidth',LW2, 'Color',[161 20 100]/255,'LineWidth',1)
        
        plot(tmesh'/3600,c1out'/c1i,'-k','LineWidth',LW)%,'Color',[.7 .7 .7]) % cmap2(round(3*(nc+20)/4),:)) 
        plot(tmesh'/3600,c2out'/c1i,'-','LineWidth',LW,'Color', [.6 0.6 .6]) 
        plot(tmesh'/3600,qTout'/qmT,'--','LineWidth',LW, 'Color', cmap2(round(15*(nc)/16),:)) 
        plot(tmesh'/3600,q1out'/qm1,'--','LineWidth',LW, 'Color', [0 .5  .1]); 
        plot(tmesh'/3600,q2out'/qm2,'--','LineWidth',LW, 'Color',cmap2(round(8.4*(nc)/16),:))    
        
        xlim([0,xtemax])
        xtickangle(0)
        
        % Main axis labels
        axes(h_main)
        box on
        set(h_main,'xscale','log')
        set(h_main,'yscale','lin')
        set(gca,'YTick',0:0.1:1)
        set(gca,'YTickLabel',{'0','','0.2','','0.4','','0.6','','0.8','','1'})
        ylim([1e-7,1])
        
        %Inset axis labels
        axes(h_inset)
        box on
        set(gca,'FontSize',FS1-2,'FontName','Times New Roman','LineWidth', .75)
        set(h_inset,'xscale','lin')
        set(h_inset,'yscale','lin')
        set(gca,'XTick',0:10:110)
        set(gca,'XTickLabel',{'0','','20','','40','','60','','80','','100',''})
        set(gca,'YLim',[0,1])
        set(gca,'YTick',0:0.1:1)
        set(gca,'YTickLabel',{'0','','','','','0.5','','','','','1'})
        
        figw = 17.2; 
        figh = .38*figw; 

        set(gcf,'PaperUnits','centimeters')
        set(gcf,'PaperSize',[figw, figh])
        set(gcf,'PaperPosition',[-.1*figw 0 1.2*figw figh])
        if Case == 0
            print(gcf,'./Figures/fig_13.pdf','-dpdf');
        elseif Case == 1 
            print(gcf,'./Figures/Not_in_paper','-dpdf');
        end 
           
    elseif  Plot == 2 %Plot  breakthrough curves
        
        %Plotting parameters
        nc = 100; 

        %Plot the insets for Figures 10 and 15 when Figures 10 and 15 are
        %generated, respectively
        if Study == 1 && Exp ==3 
            Qss = [30 40 50];
            
            %Plotting parameters
            LW = 1; LW2 = .4; FS =8; 
            cmap = parula(nc); 
            cmap = cmap(2:end,:); 
            cmaps = [cmap(round((nc+20)/4),:); cmap(round((nc+20)/2),:); cmap(round(3*(nc+20)/4)-10,:) ]; 
            cmap2 = rot90(cmap,2); 
            cmaps2 = [ cmap2(30,:); cmap2(40,:); cmap2(50,:)];
            
            if Case == 0
                %MRC     
                ka1s = [ 0.273455045879841   0.100939425788178   0.111139166357784]*1e-3;
                kaTs_M = [ 0.054820055676501   0.069072310356778   0.088011083127391];
                ka2s = [0.000528598249429   0.001023045183623   0.001888445703099];
                
                %Linear best fit
                c_MT = polyfit(Qss,kaTs_M,1);
                c_M1 = polyfit(Qss,ka1s,1);
                c_M2 = polyfit(Qss,ka2s,1);
                
                % Display evaluated equation y = m*x + b
                disp(['Equation is y = ' num2str(c_MT(1)) '*x v ' num2str(c_MT(2))])
                disp(['Equation is y = ' num2str(c_M1(1)) '*x v ' num2str(c_M1(2))])
                disp(['Equation is y = ' num2str(c_M2(1)) '*x v ' num2str(c_M2(2))])
                
                % Evaluate fit equation using polyval
                fitting_MRC_kT = c_MT(1)*linspace(0,60,100)+c_MT(2);
                fitting_MRC_k1 = c_M1(1)*linspace(0,60,100)+c_M1(2);
                fitting_MRC_k2 = c_M2(1)*linspace(0,60,100)+c_M2(2);
                
                % Plot figure
                figure(101)
                plot(linspace(0,60,100), fitting_MRC_kT, '-', 'color', [179/255, 52/255, 128/255], 'linewidth',LW)
                hold on
                plot(linspace(0,60,100), fitting_MRC_k1, '-.', 'color', [179/255, 52/255, 128/255], 'linewidth',LW)
                plot(linspace(0,60,100), fitting_MRC_k2 , ':', 'color', [179/255, 52/255, 128/255], 'linewidth',LW)
                scatter(  30 , kaTs_M(1) , 30, 'marker','*', 'MarkerEdgeColor','k','LineWidth', LW2);
                scatter(  30 , ka1s(1) , 30, 'marker','v', 'MarkerEdgeColor','k','LineWidth', LW2);
                scatter(  30 , ka2s(1) , 30, 'marker','x', 'MarkerEdgeColor','k','LineWidth', 2*LW2);
                scatter(  30 , kaTs_M(1) , 30, 'marker','*', 'MarkerEdgeColor',cmaps(1,:),'LineWidth', LW2);
                scatter(  30 , ka1s(1) , 30, 'marker','v', 'MarkerEdgeColor',cmaps(1,:),'LineWidth', LW2);
                scatter(  30 , ka2s(1) , 30, 'marker','x', 'MarkerEdgeColor',cmaps(1,:),'LineWidth', 2*LW2);
                scatter(  40 , [kaTs_M(2)], 30, 'marker','*', 'MarkerEdgeColor',cmaps(2,:),'LineWidth', LW2);
                scatter(  40 , [ka1s(2)], 30, 'marker','v', 'MarkerEdgeColor',cmaps(2,:),'LineWidth', LW2);
                scatter(  40 , [ka2s(2)], 30, 'marker','x', 'MarkerEdgeColor',cmaps(2,:),'LineWidth', 2*LW2);
                scatter(  50, [kaTs_M(3)], 30, 'marker','*', 'MarkerEdgeColor',cmaps(3,:),'LineWidth', LW2);
                scatter(  50, [ka1s(3)], 30, 'marker','v', 'MarkerEdgeColor',cmaps(3,:),'LineWidth', LW2);
                scatter(  50, [ka2s(3)], 30, 'marker','x', 'MarkerEdgeColor',cmaps(3,:),'LineWidth', 2*LW2);
                
                %Format figure and export as pdf
                figw = 4; % cm
                figh = .6*figw; 
                box on
                set(gca,'FontSize',FS,'FontName','Times New Roman','linewidth',LW)
                xlabel('$Q$','Interpreter','latex')
                ylabel('$k^\mathrm{a}$','Interpreter','latex')
                
                set(gca,'XLim',[0,60])
                set(gca,'XTick',0:10:60)
                set(gca,'XTickLabel',{'0','','20','','40','','60'})
                set(gca,'YLim',[0,0.1])
                set(gca,'YTick',0:0.02:0.1)
                set(gca,'YTickLabel',{'0','','','','','0.1'})
                
                set(gcf,'PaperUnits','centimeters')
                set(gcf,'PaperSize',[figw figh])
                set(gcf,'PaperPosition',[0 0 figw figh])
                print(gcf,'-dpdf','./Figures/fig_10_inset.pdf');
                
            elseif Case == 1
            
                kaTs_T =[  0.052961122301140   0.068286665642303   0.086629729906708];
                c_T = polyfit(Qss,kaTs_T,1);
                
                % Display evaluated equation y = m*x + b
                disp(['Equation is y = ' num2str(c_T(1)) '*x v ' num2str(c_T(2))])
                
                % Evaluate fit equation using polyval
                fitting_TMRC = c_T(1)*linspace(0,60,100)+c_T(2);
                
                %Plot figure 
                figure(151)
                plot(linspace(0,60,100), fitting_TMRC, 'color', [179/255, 52/255, 128/255], 'linewidth',LW)
                hold on
                scatter(  30, kaTs_T(1), 30, 'marker','*', 'MarkerEdgeColor',cmaps2(1,:),'LineWidth', LW2);
                scatter(  40  , kaTs_T(2), 30, 'marker','*', 'MarkerEdgeColor',cmaps2(2,:),'LineWidth', LW2);
                scatter(   50 , kaTs_T(3), 30, 'marker','*', 'MarkerEdgeColor',cmaps2(3,:),'LineWidth', LW2);
                
                %Format figure and export as pdf
                figw = 4; % cm
                figh = .6*figw; 
                box on
                set(gca,'FontSize',FS,'FontName','Times New Roman','linewidth',LW)
                xlabel('$Q$','Interpreter','latex')
                ylabel('$k_\mathrm{T}^\mathrm{a}$','Interpreter','latex')
                
                set(gca,'XLim',[0,60])
                set(gca,'XTick',0:10:60)
                set(gca,'XTickLabel',{'0','','20','','40','','60'})
                set(gca,'YLim',[0,0.1])
                set(gca,'YTick',0:0.02:0.1)
                set(gca,'YTickLabel',{'0','','','','','0.1'})
                
                set(gcf,'PaperUnits','centimeters')
                set(gcf,'PaperSize',[figw figh])
                set(gcf,'PaperPosition',[0 0 figw figh])
                print(gcf,'-dpdf','./Figures/fig_15_inset.pdf');
            end 
        end 
        
        %Plot main figure of Figures 10 and 15 
        if Study == 2
            if Case == 0
                figure(10)
                subplot(121)
                hold on 
                title('\textbf{Full model: Varying} $c_\mathrm{F}^\mathrm{f}$','Interpreter','latex');
                cmap=copper(nc);
                cmaps = [cmap(round((nc+20)/4),:); cmap(round((nc+20)/2),:); cmap(round(3*(nc+20)/4)-10,:)];
            elseif Case == 1
                figure(15)
                subplot(121)
                hold on 
                title('\textbf{Reduced model: Varying} $c_\mathrm{F}^\mathrm{f}$','Interpreter','latex');
                cmap=pink(nc);
                cmaps = [cmap(6,:); cmap(25,:); cmap(52,:)];
            end 
        elseif Study == 1
            if Case ==0 
                figure(10)
                subplot(122)
                hold on 
                title('\textbf{Full model: Varying} $Q$','Interpreter','latex')
            elseif Case == 1
                figure(15)
                subplot(122)
                hold on 
                title('\textbf{Reduced model: Varying} $Q$','Interpreter','latex')
            end 
            
            %Define colour maps
            cmap = parula(nc); 
            cmap = [cmap(2:end,:)];
            cmaps = [cmap(round((nc+20)/4),:); cmap(round((nc+20)/2),:); cmap(round(3*(nc+20)/4)-10,:)];
            if Case == 1
                cmap = rot90(cmap,2); 
                cmaps = [ cmap(30,:); cmap(40,:); cmap(50,:)];
            end
        end 
        if Exp == 1   
            scatter(texp(1:end),cexp(1:end),'marker','o', 'MarkerEdgeColor',cmaps(Exp,:),'LineWidth', .3);
            hold all     
            plot(tmesh'/3600,c1out'/c1i,'LineWidth',LW,'Color', cmaps(Exp,:))
            xlim([texp(1) max(texp)]);
        elseif Exp == 2
            scatter(texp(1:end),cexp(1:end),'marker','square', 'MarkerEdgeColor',cmaps(Exp,:),'LineWidth', .3);
            plot(tmesh'/3600,c1out'/c1i,'LineWidth',LW, 'Color', cmaps(Exp,:))
        elseif Exp == 3 
            scatter(texp(1:end),cexp(1:end),'marker','diamond', 'MarkerEdgeColor',cmaps(Exp,:),'LineWidth', .4);
            plot(tmesh'/3600,c1out'/c1i,'LineWidth',LW,'Color', cmaps(Exp,:))
        else
            plot(tmesh'/3600,c1out'/c1i,'LineWidth',LW, 'LineStyle','--', 'Color', [0.6 0.6 0.6])
        end

        %Repeat the curve of repeat experiment 
        if Study ==1 && Exp ==1 
            subplot(121)
            plot(tmesh'/3600,c1out'/c1i,'LineWidth',LW,'Linestyle','--','Color', cmaps(Exp,:))
        elseif Study == 2 && Exp ==2 
            subplot(122)
            plot(tmesh'/3600,c1out'/c1i,'LineWidth',LW, 'Linestyle','--','Color', cmaps(Exp,:))
        end 
        grid off
        box on 
        ylim([-0.1 1.01])
        set(gca,'FontSize',FS1,'FontName','Times New Roman','LineWidth', 1)

    %Plot Figures 12 and 17
    elseif Plot == 3
        if Case ==0
            figure(12)
        elseif Case == 1
            figure(17)
        end 
        hold on 
        %Define colour maps
        if Case ==0
            cmaps = parula(length(tmesh));
            cmaps = flipud(cmaps);
        else 
            cmaps = parula(length(tmesh));
            cmaps = fliplr(cmaps);
        end 
        for i = 1:length(tmesh)
            plot(xmesh./Lb*10, c1(i,:)'/c1i, 'Color', cmaps(i,:), 'LineWidth',1); 
        end
        hold on
        plot(xmesh./Lb*10, c1(Long_plot_early,:)/c1i, 'k--', 'LineWidth',1.4); 

        %Format and export Figure 13 as pdf
        xlab=xlabel('$L\ $ (cm)','Interpreter','latex','FontSize',FS1);
        ylab=ylabel('$c_\mathrm{F}/c_\mathrm{F}^\mathrm{f}$','Interpreter','latex','FontSize',FS1);
        xlab.FontSize=FS1;
        ylab.FontSize=FS1;
        xlim([xmesh(1)/Lb*10 xmesh(end)/Lb*10])
        ylim([0,1])
        figw = 17.2; % cm
        figh = .3*figw; 
        box on
        set(gca,'FontSize',FS1,'FontName','Times New Roman','linewidth',1)
        set(gcf,'PaperUnits','centimeters')
        set(gcf,'PaperSize',[figw figh])
        set(gcf,'PaperPosition',[-.06*figw 0 1.13*figw figh])
        if Case ==0
            print(gcf,'-dpdf','./Figures/fig_12.pdf');
        elseif Case == 1 
            print(gcf,'-dpdf','./Figures/fig_17.pdf');
        end 
    end 
end 

