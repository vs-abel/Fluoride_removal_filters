function ycalc = Feed_conc_opt_helper_TMRC(paropt,texp,D1,D2,vs,qm1,qmT,qm2,c2i,ka1,ka2,KT,sizes,cexp,z_points)
    %Code written by L. C. Auton, based on codes by M. Martínez I. Àvila and A. Valverde

    %Unpack parameters to optimise 
    kaT=paropt(1);
  
    kd1=0;
    kdT=kaT/KT;
    kd2=0;
    
    ycalc=[];
    
    % Preallocate vector size for speed
    xmesh= zeros(z_points,3);
    for iExp=1:3
        xmesh(:,iExp) = linspace(0, paropt(iExp+4), z_points);
        %Unpack other paramters to optimise
        c1i=paropt(iExp+1);
        f = paropt(iExp+7);

        %Construct physcial parameters
        rhob1=(1-f)*900;               
        rhob2=f*980;
        phi=(1-f)*0.5+f*0.6;
        v=vs/phi;%Interstitial velocity [dm/s]
        
        if iExp==1
            texpi = texp(1:sizes(1));
        elseif iExp==2
            texpi = texp(sizes(1)+1:sizes(1)+sizes(2));
        elseif iExp==3
            texpi = texp(sizes(1)+sizes(2)+1:end);
        end
        
        texps=texpi*3600;
        tmesh = texps;

        mpdepe = 0;
        sol = pdepe(mpdepe,@(x,t,u,dudx) ...
            pdepefun3opt(x,t,u,dudx,v,D1,D2,rhob1,rhob2,phi,ka1,kaT,ka2,kd1,kdT,kd2,qm1,qmT,qm2),...
            @(x) pdepeic3opt(x,c2i),@(xl,ul,xr,ur,t) pdepebc3opt(xl,ul,xr,ur,t,v,c1i,c2i),...
            xmesh(:,iExp),tmesh);
        
        %Extract cF and calculate cF at outlet 
        c1=sol(:,:,1); 
        c1ciout=c1(:,end)/c1i;
        
        %Construct function output quantity
        ycalc=[ycalc,c1ciout'];
   
    end
end

