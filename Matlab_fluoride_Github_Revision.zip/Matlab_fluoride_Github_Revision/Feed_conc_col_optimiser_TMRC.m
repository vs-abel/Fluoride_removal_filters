close all; clear all; clc; format long 
%Code written by L. C. Auton, based on codes by M. Martínez I. Àvila and A. Valverde

%Load experimental data
[Data5C, Data10C, Data15C, Data_tsC, Data_csC] =Data_Concentrations;
 
% Batch optimised values 
%TMRC
qmT = 0.0069001;
%Set MRC paramters all to 0 (enables use of same functions)
qm1 = 0; qm2 = 0; ka1 = 0; ka2 = 0; kd1 = 0; kd2 = 0;

%Define parameters used to calculate  KT
gamma_kin=1; 
F_fac = 1/19000; % factor for fluoride to convert between mol and mg 
OH_fac = 1/17000; % factor for hydroxide to convert between mol and mg 
cOH0=1.7000e-3*OH_fac; %Initial concentration of OH in mol/l      

c_TMRC = F_fac*[50 6.9 5.8 4.9 3.6 2 0.5 0.45 0.4 0.4 0.3 0.08 0.08 0.08];%TMRC kinetic data

%Calculate KT
KT = (c_TMRC(1)-c_TMRC(end))*(c_TMRC(1)-c_TMRC(end)+cOH0)/c_TMRC(end)...
/(gamma_kin*qmT-c_TMRC(1)+c_TMRC(end));

% Define parameters used to calculare the velocity and the flow rate 
Q = 30/(24*3600);            %Flow rate [dm^3/s]
Db=4.4e-1;          %dm      
Sb=pi*(Db^2)/4;     %dm^2
vs=Q/Sb;  
%The effective diffusivity
D1=2.9e-5;
D2=2.9e-5;

%Initial guesses and bounds for experimental parameters to be optimised
c1i_DB0 = [ 5.14481   9.500002  14.500008 ]*F_fac;
c1i_DB0_LB =[ 4.5  , 9.5, 14.5  ]*F_fac;
c1i_DB0_UB =[ 5.5  , 10.5, 15.5  ]*F_fac;
fs0 = [1.04999   1.049999   1.049999]/41; 
fs_LB = [.95, .95,  .95 ]/41; 
fs_UB = [1.05, 1.05,  1.05 ]/41; 
Lb0 =[1.049998864394567   1.049999740689272   1.049999068744482];   %dm 
Lb0_LB = [0.95 0.95 0.95];
Lb0_UB = [1.05 1.05 1.05];

%Define number of points in spatial discretisations
z_points=200;

%Define experimental data 
sizes=[max(size(Data_tsC{1})),max(size(Data_tsC{2})),max(size(Data_tsC{3}))];
texp=[Data_tsC{1},Data_tsC{2},Data_tsC{3}];
cexp=[Data_csC{1},Data_csC{2},Data_csC{3}];

%Construct full ICs and lower and upper bounds
paropt0=[0.05697,c1i_DB0(1),c1i_DB0(2),c1i_DB0(3), ...
    Lb0(1),Lb0(2),Lb0(3),fs0(1), fs0(2), fs0(3)];
LB=[1e-3, c1i_DB0_LB(1),c1i_DB0_LB(2),c1i_DB0_LB(3),...
    Lb0_LB(1),Lb0_LB(2),Lb0_LB(3),fs_LB(1), fs_LB(2), fs_LB(3)];
UB=[1,c1i_DB0_UB(1),c1i_DB0_UB(2),c1i_DB0_UB(3),...
    Lb0_UB(1),Lb0_UB(2),Lb0_UB(3),fs_UB(1), fs_UB(2), fs_UB(3)];

%Required to add a nonlinear constraint into the optimisation
A = []; b = []; Aeq = []; beq = [];

%Define options for the optimisation 
opts =optimoptions(@lsqcurvefit,'Display','iter','FunctionTolerance',1e-14,...
    'MaxIterations',500, 'StepTolerance',1e-8);

% %Optimise
% [paropt,resnorm,residual,exitflag,output,lambda,jacobian] = ...
%     lsqcurvefit(@(paropt,xexp)Feed_conc_opt_helper_TMRC...
%     (paropt,xexp,D1,D2,vs,qm1,qmT,qm2,cOH0,ka1,ka2,KT,sizes,cexp,z_points),...
%     paropt0,texp,cexp,LB,UB,opts);

%Saved optimal values 
paropt = [0.056909999095053   0.000270792417733   0.000500000000023   0.000763157898600...
1.049999995342633   1.049999997604982   1.049999990464032   0.025609755402224...
0.025609755876482   0.025609755848102]; 

% Unpack the optimised parameters
kaTopt=paropt(1); 
cfopt = paropt(2:4); 
cfopt_units = paropt(2:4)/F_fac; 
Lbopt = paropt(5:7);
fopt_percentage = paropt(8:10)*41;

kdTopt= kaTopt/KT;
ka2opt= 0;
ka1opt = 0; 
kd2opt= 0;
kd1opt = 0; 

number = 3; 

%Preallocate vectors for speed
xmesh = zeros(z_points,number);
c1{1} = zeros(length(Data_tsC{1}), z_points);
c1{2} = zeros(length(Data_tsC{2}), z_points);
c1{3} = zeros(length(Data_tsC{3}), z_points);
c1out{1} = zeros(length(Data_tsC{1}),1) ; 
c1out{2} = zeros(length(Data_tsC{2}),1) ; 
c1out{3} = zeros(length(Data_tsC{3}),1) ; 
tmesh_exp{1} = zeros(length(Data_tsC{1}),1); 
tmesh_exp{2} = zeros(length(Data_tsC{2}),1); 
tmesh_exp{3} = zeros(length(Data_tsC{3}),1); 
val_SSE= zeros(1,3);
val_SST= val_SSE;
R_2= val_SSE;

for  iExp = 1:number
    % Construct spatial mesh for each experiment 
    xmesh(:,iExp) = linspace(0, paropt(iExp+4), z_points);

    % Unpack the remaining optimised parameters
    c1i=paropt(iExp+1);
    f = paropt(iExp+7);

    %Calculate physcial quantities to be used to solve the pde. 
    rhob1=(1-f)*900;               
    rhob2=f*980;
    phi=(1-f)*0.5+f*0.6;
    v=vs/phi;     %Interstitial velocity [dm/s]

    %Unpack experimental data
    cexpiExp = Data_csC{iExp}; 
    texpiExp = Data_tsC{iExp};
    texps=texp*3600;
    tmax=max(texps);
    
    %Construct temporal mesh which corresponds to experimental times  
    texps=texpiExp*3600;
    tmesh_exp{iExp}(:) = texps;
    
    mpdepe = 0;
    sol = pdepe(mpdepe,@(x,t,u,dudx) ...
    pdepefun3opt(x,t,u,dudx,v,D1,D2,rhob1,rhob2,phi,ka1,...
    kaTopt,ka2opt,kd1opt,kdTopt,kd2opt,qm1,qmT,qm2),...
    @(x) pdepeic3opt(x,cOH0),@(xl,ul,xr,ur,t) ...
    pdepebc3opt(xl,ul,xr,ur,t,v,c1i,cOH0),xmesh(:,iExp),tmesh_exp{iExp}(:));
    
    %Extract the concentration of fluoride (cF)
    c1{iExp}=sol(:,:,1);
    %Finding cF at the outlet
    c1out{iExp}=c1{iExp}(:,end);

    %Calculate GoF parameters
    val_SSE(iExp) = sum( (cexpiExp'-c1out{iExp}/c1i).^2) ;
    val_SST(iExp) = sum( (cexpiExp'-mean(cexpiExp)).^2);
    R_2(iExp) = 1-val_SSE(iExp)./val_SST(iExp);

end
%Table 4 (left half)
disp(['Table 4 (left): Optimised and goodness of fit parameters for column ...' ...
    'filter for case of varying feed concentration and the full model'])
disp(['kaT = ' num2str(kaTopt) ' l/(mol*s)'])
disp(['cFf= ' num2str(cfopt_units) '  mg/l  (' num2str(cfopt)  ')    (mol/l)'])
disp(['f= ' num2str(fopt_percentage) '/41    --'])
disp(['L= ' num2str(Lbopt/10) '   m'])
disp(['SSE = ' num2str(val_SSE) '    --'])
disp(['R-squared = ' num2str(R_2) '    --'])


