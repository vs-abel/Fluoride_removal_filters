close all; clear all; clc
%Code written by L. C. Auton, based on codes by M. Martínez I. Àvila and A. Valverde

%Load experimental data
[Data30F, Data40F, Data50F, Data_tsF, Data_csF] =Data_Flow_rates; 

% Batch optimised values 
%TMRC
qmT = 0.0069001;
%Set MRC paramters all to 0 (enables use of same functions)
qm1 = 0; qm2 = 0; ka1 = 0; ka2 = 0; kd1 = 0; kd2 = 0;

%Define parameters used to calculate  KT
gamma_kin=1; 
F_fac = 1/19000; % factor for fluoride to convert between mol and mg 
OH_fac = 1/17000; % factor for hydroxide to convert between mol and mg 
cOH0=1.7000e-3*OH_fac; %Initial concentration of OH in mol/l      

c_TMRC = F_fac*[50 6.9 5.8 4.9 3.6 2 0.5 0.45 0.4 0.4 0.3 0.08 0.08 0.08];%TMRC kinetic data

%Calculate KT
KT = (c_TMRC(1)-c_TMRC(end))*(c_TMRC(1)-c_TMRC(end)+cOH0)/c_TMRC(end)...
/(gamma_kin*qmT-c_TMRC(1)+c_TMRC(end));

% Define parameters used to calculare the velocity and the flow rate 
Qs = [30 40 50]/(24*3600);            %Flow rate [dm^3/s]
Db=4.4e-1;          %dm      
Sb=pi*(Db^2)/4;     %dm^2
%The effective diffusivity
D1=2.9e-5;
D2=2.9e-5;

%Initial guesses for parameters to be optimised
kaT0= [0.0529, 0.069, 0.087];
fs0 = [1.0499    1.04    0.951]/41;
cfs0 = [9.501   9.6   10.4]*F_fac;
Lbs0=[1.0499, 1.05, 0.951]; 

%Number of points used to discretise the spatial domain
z_points=200;

number = 3; 

%Preallocate vectors for speed
cfopt = zeros(1,3);
fopt = cfopt; 
Lbopt = cfopt;
ka1opt = cfopt;
kaTopt = cfopt;
ka2opt = cfopt;
kd1opt = cfopt;
kdTopt = cfopt;
kd2opt = cfopt;
cfopt_units= cfopt;
fopt_percentage= cfopt;
val_SSE= cfopt;
val_SST= cfopt;
R_2= cfopt;
xmesh = zeros(z_points,3);
c1{1} = zeros(length(Data_tsF{1}), z_points);
c1{2} = zeros(length(Data_tsF{2}), z_points);
c1{3} = zeros(length(Data_tsF{3}), z_points);
c1out{1} = zeros(length(Data_tsF{1}),1); 
c1out{2} = zeros(length(Data_tsF{2}),1); 
c1out{3} = zeros(length(Data_tsF{3}),1); 
tmesh_exp{1} = zeros(length(Data_tsF{1}),1); 
tmesh_exp{2} = zeros(length(Data_tsF{2}),1); 
tmesh_exp{3} = zeros(length(Data_tsF{3}),1); 

conf=cell(1,number);

for iExp = 1:number

    % Unpack flow rate and velocity    
    Q = Qs(iExp);
    vs=Q/Sb;   

    %Unpack experimental data
    cexp = Data_csF{iExp}; 
    texp = Data_tsF{iExp};

    %Construct temporal mesh which corresponds to experimental times  
    texps=texp*3600;
    tmesh_exp{iExp}(:) = texps;

    % Prescribe initial conditions and bounds for the optimisation
    paropt0=[cfs0(iExp),fs0(iExp), Lbs0(iExp), kaT0(iExp)];
    if iExp ==3 
        LB=[9.5*F_fac, 0.95/41, .95,  0.06];
        UB=[10.5*F_fac, 1.05/41, 1.05 0.11];
    else 
        LB=[9.5*F_fac, 0.95/41, .95, 1e-6];
        UB=[10.5*F_fac, 1.05/41, 1.05, 1e2];
    end 
    
    %Define options for optimisation algorithm
    opts =optimoptions(@lsqcurvefit,'Display','iter','FunctionTolerance',1e-14,...
        'MaxIterations',500, 'StepTolerance',1e-8, 'OptimalityTolerance', 1e-8);

    % Optimise 
    [paropt,resnorm,residual,exitflag,output,lambda,jacobian] = lsqcurvefit(@(paropt,texp)...
     Varying_flow_rate_opt_helper_TMRC(paropt,texp,D1,D2,vs,qmT,cOH0,KT,tmesh_exp{iExp}(:),z_points),...
     paropt0,texp,cexp,LB,UB,opts);
 
    conf{iExp}=nlparci(paropt, residual, 'jacobian', jacobian);
 
    % Unpack the optimised parameters
    cfopt(iExp)=paropt(1);
    fopt(iExp) = paropt(2);
    Lbopt(iExp)=paropt(3);
    kaTopt(iExp)=paropt(4);
    kdTopt(iExp)=kaTopt(iExp)/KT;
    cfopt_units =  cfopt/F_fac;
    fopt_percentage = fopt*41;

    %Calculate physcial quantities to be used to solve the pde. 
    rhob1=(1-fopt(iExp))*900;               
    rhob2=fopt(iExp)*980;
    phi=(1-fopt(iExp))*0.5+fopt(iExp)*0.6;
    v=vs/phi;   %Interstitial velocity [dm/s]

    %Construct spatial mesh 
    xmesh(:,iExp) = linspace(0, Lbopt(iExp), z_points);

    mpdepe = 0;
    sol = pdepe(mpdepe,@(x,t,u,dudx)...
        pdepefun3opt(x,t,u,dudx,v,D1,D2,rhob1,rhob2,phi,...
        ka1,kaTopt(iExp),ka2,kd1,kdTopt(iExp),kd2...
        ,qm1,qmT,qm2),@(x) pdepeic3opt(x,cOH0),@(xl,ul,xr,ur,t) ...
        pdepebc3opt(xl,ul,xr,ur,t,v,cfopt(iExp),cOH0),xmesh(:,iExp),tmesh_exp{iExp}(:));

    %Extract the concentration of fluoride (cF)
    c1{iExp}=sol(:,:,1);
 
    %Finding cF at the outlet
    c1out{iExp}=c1{iExp}(:,z_points);

    %Calculate GoF parameters
    val_SSE(iExp) = sum( (cexp'-c1out{iExp}/cfopt(iExp)).^2); 
    val_SST(iExp) = sum( (cexp'-mean(cexp)).^2);
    R_2(iExp) = 1-val_SSE(iExp)./val_SST(iExp);

end

%Table 4 (right half)
disp(['Table 4 (right): Optimised and goodness of fit parameters for column ...' ...
    'filter for case of varying Q and the reduced model'])
disp(['kaT = ' num2str(kaTopt) ' l/(mol*s)'])
disp(['cFf= ' num2str(cfopt_units) '  mg/l   (' num2str(cfopt)  ')     (mol/l)'])
disp(['f= [' num2str(fopt_percentage) ']/41     --'])
disp(['L= ' num2str(Lbopt/10) '   m'])
disp(['SSE = ' num2str(val_SSE) '   --'])
disp(['R-squared = ' num2str(R_2) '   --'])
